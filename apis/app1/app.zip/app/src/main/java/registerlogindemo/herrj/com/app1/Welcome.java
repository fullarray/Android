package registerlogindemo.herrj.com.app1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import registerlogindemo.herrj.com.app1.Welcome;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_activity);
    }
}
